<!DOCTYPE html>
<html xmlns="https://www.w3.org/1999/xhtml" class="mobile">
<head>
	<meta charset="utf-8" />
	
	<title>Lirik Lagu Ache - Gwen Stefani - KapanLagi.com</title>
	<meta name="description" content="lirik lagu ache-gwen stefani | dari m.kapanlagi.com: layanan mobile dari situs entertainment terbesar indonesia, kapanlagi.com" />
	<meta name="keywords" content="lirik lagu ache-gwen stefani , foto, fotos, photos, images, image, berita, infotainment, gossip, gosip, artis, artis indonesia, indonesia, game, entertainment, film, bioskop, resensi, musik, seks, seksologi, zodiac" />
	
	<meta http-equiv="cache-control" content="public, no-transform" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<meta name="apple-mobile-web-app-capable" content="yes" />
	
	
	<meta property="og:title" content="Lirik Lagu Ache - Gwen Stefani - KapanLagi.com" />
	<meta property="og:description" content="lirik lagu ache-gwen stefani | dari m.kapanlagi.com: layanan mobile dari situs entertainment terbesar indonesia, kapanlagi.com" />
	<meta property="og:type" content="article" />
	<meta property="og:url" content="https://m.kapanlagi.com/lirik/artis/gwen-stefani/ache" />
	<meta property="og:image" content="https://cdns.klimg.com/kapanlagi.com/v5/i/channel/music/newlogokl-lirik.jpg" />
	<meta property="og:site_name" content="KapanLagi.com" />
	<meta property="fb:app_id" content="166048096750307" />	
	
	 
	<link rel="canonical" href="https://lirik.kapanlagi.com/artis/gwen-stefani/ache/4q:/a.9t.48/v5/js/m/rd/linkid.js">
	
	<link rel="manifest" href="/manifest.json">
	<link rel="dns-prefetch" href="//placehold.it" />
	<link rel="dns-prefetch" href="//ajax.googleapis.com" />
	<link rel="dns-prefetch" href="https://cdns.klimg.com/" />
	<link rel="shortcut icon" href="https://cdns.klimg.com/kapanlagi.com/v5/i/favicon.ico" />
	<link rel="apple-touch-icon" href="https://cdns.klimg.com/kapanlagi.com/v5/i/channel/apple-touch-icon.png" />
	<link rel="apple-touch-icon" href="https://cdns.klimg.com/kapanlagi.com/v5/i/channel/apple-touch-icon-precomposed.png" />
	<link rel="apple-touch-icon" href="https://cdns.klimg.com/kapanlagi.com/v5/i/channel/apple-touch-icon-114x114-precomposed.png" />
	<link rel="apple-touch-icon" href="https://cdns.klimg.com/kapanlagi.com/v5/i/channel/apple-touch-icon-120x120-precomposed.png" />
	<link rel="apple-touch-icon" href="https://cdns.klimg.com/kapanlagi.com/v5/i/channel/apple-touch-icon-152x152-precomposed.png" />
	
	
	<link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Noto+Sans:400,400i,700,700i" />
	<link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" />
	<link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Noto+Sans:400,700" />
	
	<link rel="stylesheet" href="https://cdns.klimg.com/a.kapanlagi.com/v5/css/m2/1.18k/entertainment.css" />
	<script type="text/javascript" src="https://cdns.klimg.com/a.kapanlagi.com/v5/js/m/1.18o/entertainment.js"></script>
	
	
	<style>
		@font-face {
			font-family: 'Gotham Bold';
			src: url('https://a.kapanlagi.com/v5/m/font/Gotham-Bold-Regular.ttf') format('truetype');
		}
		.async-hide { opacity: 0 !important}
	</style>	
		
	<!-- BEGIN CRITEO LOADER -->
	<script async="async" type="text/javascript" src="https://static.criteo.net/js/ld/publishertag.js"></script>
	<script>
		window.Criteo = window.Criteo || {};
		window.Criteo.events = window.Criteo.events || [];
	</script>
	<!-- END CRITEO LOADER -->
	
	<!--BEGIN KLY GLOBAL OBJECT-->
	<script type="text/javascript">
		window.kly = {};
		window.kly.env = "production";
		window.kly.baseAssetsUrl = "";
		window.kly.gtm = {
			"adblockExists":"no",
			"articleId":286376,
			"articleTitle":"Lirik Lagu Ache - Gwen Stefani",
			"category":"article",
			"editors":"",
			"editorialType":"editorial",
			"embedVideo":"",
			"pageTitle":"Lirik Lagu Ache - Gwen Stefani - KapanLagi.com",
			"publicationDate":"",
			"publicationTime":"",
			"subCategory":"Lirik",
			"subSubCategory":"artis",
			"tag":"",
			"authors":{
				"type":"",
				"names":""
			},
			"numberOfWords":273,
			"enabled":true,
			"log":false,
			"imageCreation":false,
			"type":"TextTypeArticle",
			"videos":"",
			"partner":"",
			"isSEO":false,
			"contributors":"",
			"reporters":"",
			"photographers":""
		};
		window.kly.platform = "Mobile";
		window.kly.pageType = "ReadPage";
		window.kly.channel = {
			"id":0,
			"name":"Lirik",
			"full_slug":"lirik"
		};
		window.kly.category = {
			"id":0,
			"name":"GWEN-STEFANI",
			"full_slug":"\/lirik\/artis\/gwen-stefani\/"
		};
		window.kly.article = {
			"id":286376,
			"title":"Lirik Lagu Ache - Gwen Stefani",
			"type":"TextTypeArticle",
			"shortDescription":"lirik lagu ache-gwen stefani | dari m.kapanlagi.com: layanan mobile dari situs entertainment terbesar indonesia, kapanlagi.com",
			"keywords":"lirik lagu ache-gwen stefani , foto, fotos, photos, images, image, berita, infotainment, gossip, gosip, artis, artis indonesia, indonesia, game, entertainment, film, bioskop, resensi, musik, seks, seksologi, zodiac",
			"isAdvertorial":false,
			"isMultipage":false,
			"isAdultContent":false,
			"verifyAge":false,
			"publishDate":""
		};
		window.kly.site = "Kapanlagi";
		window.kly.related_system = "tag";

	</script>
	<!--ENDOF KLY GLOBAL OBJECT-->
	
	<!-- Google Tag Manager -->
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-5Q9XWN9');</script>
	<!-- End Google Tag Manager -->

	<!-- Page-hiding snippet (recommended)  -->
	<script type="text/javascript">
	(function(a,s,y,n,c,h,i,d,e){s.className+=' '+y;h.start=1*new Date;
	h.end=i=function(){s.className=s.className.replace(RegExp(' ?'+y),'')};
	(a[n]=a[n]||[]).hide=h;setTimeout(function(){i();h.end=null},c);h.timeout=c;
	})(window,document.documentElement,'async-hide','dataLayer',4000,
	{'GTM-WVRXG8X':true});

	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

	ga('create', 'UA-108534636-1', 'auto', {allowLinker: true, cookieDomain: 'm.kapanlagi.com'});
	ga('require', 'linkid', 'linkid.js');
	ga('require', 'displayfeatures');
	ga('require', 'GTM-WVRXG8X');
	</script>
	<!-- end of Page-hiding snippet (recommended)  -->		
	
	<!--GA CODE-->
	<script>
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
		
		// ga('create', 'UA-77158561-1', 'auto');
		ga('create', 'UA-108534636-1', 'auto');
		
		// ga('send', 'pageview');
	</script>
	<!--END OF GACODE-->
	
	<!-- Start Alexa Certify Javascript -->
	<script type="text/javascript">
	_atrk_opts = { atrk_acct:"ry1us1FYxz20cv", domain:"kapanlagi.com",dynamic: true};
	(function() { var as = document.createElement('script'); as.type = 'text/javascript'; as.async = true; as.src = "https://certify-js.alexametrics.com/atrk.js"; var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(as, s); })();
	</script>
	<noscript><img src="https://certify.alexametrics.com/atrk.gif?account=ry1us1FYxz20cv" style="display:none" height="1" width="1" alt="" /></noscript>
	<!-- End Alexa Certify Javascript -->
	
	<!-- Facebook Pixel Code -->
	<script>
	!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
	n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
	n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
	t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
	document,'script','https://connect.facebook.net/en_US/fbevents.js');
	fbq('init', '1178703115477182', {
	em: 'insert_email_variable,'
	});
	fbq('track', 'PageView');
	</script>
	<noscript><img height="1" width="1" style="display:none"
	src="https://www.facebook.com/tr?id=1178703115477182&ev=PageView&noscript=1"
	/></noscript>
	<!-- DO NOT MODIFY -->
	<!-- End Facebook Pixel Code -->
	
	<!-- One OneSignal Push notification -->
	<script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async></script>
	<script>
		var OneSignal = window.OneSignal || [];
		OneSignal.push(["init", {
			appId: "52cf8943-292c-4cc4-b23a-72c0ae1d8e84", /*Sesuai App ID Desktop/Mobile*/
			autoRegister: false,
			notifyButton: {
				enable: false /* Set to false to hide */
			},
			promptOptions: {
				actionMessage: "Dapatkan berita dan foto selebriti lebih cepat dengan aktifkan notifikasi Kapanlagi.com",
				acceptButtonText: "Ya",
				cancelButtonText: "Tidak"
			},
			welcomeNotification: {
				"title": "KapanLagi.com",
				"message": "Terima kasih sudah mengaktifkan notifikasi",
			}
		}]);
		OneSignal.push(function(){
			OneSignal.showHttpPrompt();
		});
	</script>
	<!-- End One OneSignal Push notification -->
	<!--<script type="text/javascript" src="https://a.kapanlagi.com/v5/js/m/highlightv2_addShare_box.js"></script>   -->
	<script type="text/javascript" src="https://a.kapanlagi.com/v5/js/m-native-videos-v3.js?prodtm0"></script>	
	
	
</head>
<body>
	<!-- Google Tag Manager (noscript) -->
	<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5Q9XWN9" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
	<!-- End Google Tag Manager (noscript) -->
	
	<div id="fb-root"></div>
	<div id="top_kl_logo"></div>
	
	<!--DFP SMART CODE-->
	<div id='div-gpt-ad-kapanlagi-smart-oop' style="text-align: center;background-color: #ececec; "></div>
	<!--END DFP SMART CODE-->
	
	

<!--DFP TOP FRAME CODE-->
	<div id='div-gpt-ad-kapanlagi-topfrm-oop' style='text-align: center;background-color: #ECECEC;'></div>
<!--END DFP TOP FRAME CODE-->




<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,300' rel='stylesheet' type='text/css'>   
<script type="text/javascript" src="https://a.kapanlagi.com/v5/js/m/vendor/boostrap_2.js"></script>        

<script>
        $(function() {
              $('.navbar-brand').click(function() {
                window.dataLayer = window.dataLayer || [];
                window.dataLayer.push({
                  'event': "click",
                  'feature_location': "top",
                  'feature_name': 'logo',
                  'kanal_page': 'lirik',                  
                });
              });
        });
</script>

<!--new navbar menu-->
<div class="navbar">
		<div class="container menu-utama">
				<div class="navbar-header text-center menu-kl">
						<!--HEADMENUBUTTON-->
						<button type="button" class="navbar-toggle btn-main-menu pull-left collapsed">
								<img src="https://cdns.klimg.com/kapanlagi.com/v5/m/i/assets/img/new-menu-icon.png" width="24" />
						</button>
						<!--ENDOFHEADMENUBUTTON-->
						<a class="navbar-brand" href="https://m.kapanlagi.com/"><img id="top_kl_logo" src="https://cdns.klimg.com/kapanlagi.com/v5/m/i/assets/img/logo/kllogo-mobile-entertainment-20200408.png" alt="KapanLagi" /></a>
						<!--HEADSEARCHBUTTON-->
						<button id="search_btn" type="button" class="navbar-toggle pull-right btn-search collapsed" data-toggle="collapse" data-target=".navbar-search">
								<img src="https://cdns.klimg.com/kapanlagi.com/v5/m/i/assets/img/new-search-icon.png" class="icon-search" alt="Cari" />
						</button>
						<!--ENDOFHEADSEARCHBUTTON-->
				</div>
				
				<!--HEADNAVBARMENU-->				
				<link rel="stylesheet" type="text/css" href="https://a.kapanlagi.com/v5/css/m2/update_navbar.css">
				<!--<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>-->
				<script type="text/javascript" src="https://a.kapanlagi.com/v5/js/m2/update_navbar.js"></script>
				
				<div class="navbar-menu clearfix">
						<div class="navbar-menu--header">
								<a href="/" class="navbar-menu--header-logo"><img src="https://cdns.klimg.com/kapanlagi.com/v5/m/i/assets/img/logo/kllogo-mobile-entertainment-20200408.png" alt="KapanLagi" width="150"></a>
								<a href="#" class="navbar-menu--header-close"><img src="https://cdns.klimg.com/kapanlagi.com/v5/m/i/assets/img/close.png" width="20"></a>
						</div>
						<ul class="nav list-unstyled clearfix">
								<li class="active"><a href="/trending/">Trending</a></li>
								<li><a href="/showbiz/selebriti/">Selebriti</a></li>
								<li><a href="/showbiz/hollywood/">Hollywood</a></li>
								<li><a href="/musik/">Musik</a></li>
								<li><a href="/korea/">Korea</a></li>
								<li><a href="/lirik/">Lirik Lagu</a></li>
								<li><a href="/film/">Film</a></li>
								<li><a href="/lifestyle/">Lifestyle</a></li>
								<li><a href="/kuis/">Kuis</a></li>
								<li><a href="/dangdut/">Dangdut</a></li>
								<li><a href="/showbiz/bollywood/">Bollywood</a></li>
								<li><a href="/intermezzone/">Intermezzone</a></li>
								<li><a href="/plus/">Kapanlagi Plus</a></li>
								<li><a href="/video/">Video Selebriti</a></li>
								<li><a href="/selebriti/">Profil Selebriti</a></li>
								<li><a href="/rumah-selebriti/">Rumah Selebriti</a></li>
								<li><a href="/game/">Game Gratis</a></li>
								<li class="close-main-menu2" style="display:none;">
										<a href="#">CLOSE</a>
								</li>
						</ul>
						<div class="navbar-menu--footer">
								<a href="https://company.kapanlagi.com/contact/">Kontak</a>
								<a href="https://company.kapanlagi.com/tos/">Kebijakan Privasi</a>
						</div>
				</div>
				<div class="navbar-search collapse">
						<form class="navbar-form" action="https://www.google.com/cse">
								<div class="navbar-form-search input-group">
										<span class="input-group-btn">
												<button class="btn" type="submit"><img src="https://cdns.klimg.com/kapanlagi.com/v5/m/i/assets/img/new-search-icon.png" height="20" alt="Cari" /></button>
										</span>
										<input type="hidden" value="015807142566320303553:8jzrnftshsa" name="cx">
										<input type="hidden" value="FORID:9" name="cof">
										<input type="hidden" value="UTF-8" name="ie">
										<input class="form-control" type="text" size="20" name="q" placeholder="Search Here">
										<span class="input-group-btn">
												<a href="javascript:void(0);" class="close-search3"><img src="https://cdns.klimg.com/kapanlagi.com/v5/m/i/assets/img/new-close-icon-red_rev3.png" height="15" alt="Tutup" /></a>
										</span>
								</div>
						</form>
				</div>
				<!--ENDOFHEADNAVBARMENU-->
		</div>
</div>
<!--end new navbar menu-->


<link rel="stylesheet" href="https://a.kapanlagi.com/v5/m/css/n_m_menu_newlist.css?d2" />  
<div class="container header-menu text-center">
	<ul class="menu-second list-inline">
		<li ><a href="/showbiz/" onclick="dataLayer.push({'event': 'click','feature_location': 'topnav', 'feature_name': 'header', 'feature_position': '1', 'kanal_page': 'berita'});" >BERITA</a></li>
<li ><a href="/foto/" onclick="dataLayer.push({'event': 'click','feature_location': 'topnav', 'feature_name': 'header', 'feature_position': '2', 'kanal_page': 'foto'});" >FOTO</a></li>
<li ><a href="/korea/" onclick="dataLayer.push({'event': 'click','feature_location': 'topnav', 'feature_name': 'header', 'feature_position': '3', 'kanal_page': 'korea'});" >KOREA</a></li>
<li ><a href="/musik/" onclick="dataLayer.push({'event': 'click','feature_location': 'topnav', 'feature_name': 'header', 'feature_position': '4', 'kanal_page': 'musik'});" >MUSIK</a></li>
<li ><a href="/dangdut/" onclick="dataLayer.push({'event': 'click','feature_location': 'topnav', 'feature_name': 'header', 'feature_position': '5', 'kanal_page': 'dangdut'});" >DANGDUT</a></li>
<li ><a href="/kuis/" onclick="dataLayer.push({'event': 'click','feature_location': 'topnav', 'feature_name': 'header', 'feature_position': '6', 'kanal_page': 'kuis'});" >KUIS</a></li>
<li ><a href="/selebriti/" onclick="dataLayer.push({'event': 'click','feature_location': 'topnav', 'feature_name': 'header', 'feature_position': '7', 'kanal_page': 'artis'});" >ARTIS</a></li>

	</ul>
</div>




	<div class="container">
		
<script type="text/javascript" src="https://a.kapanlagi.com/v5/js/m/pageloader.js"></script>
<link rel="stylesheet" type="text/css" href="https://a.kapanlagi.com/v5/css/m2/pageloader.css">
<div class="main-kl main-showbiz main-musik">
	

<ol class="breadcrumb text-uppercase">
	<li><a href="/">KAPANLAGI.COM</a></li>
<li>&nbsp;&raquo;&nbsp;</li>
<li><a href="/musik">MUSIK</a></li>
<li>&nbsp;&raquo;&nbsp;</li>
<li><a href="/lirik/">LIRIK LAGU</a></li>
<li>&nbsp;&raquo;&nbsp;</li>
<li><a href="/lirik/artis/gwen-stefani/">GWEN-STEFANI</a></li>

</ol>

	
	<div id="div-gpt-ad-kapanlagi-hl"></div>
	
	<!-- MAINCONTENT -->
	<div id="ajaxid-9Rh5hQA" class="ajaxcontainer infinite-paging-item">
		
<div class="artikel-detail-headline artikel-detail-lirik viewpointurl pageloader pageloader-full" data-viewpointurlid="286376" data-viewpointurl="https://m.kapanlagi.com/lirik/artis/gwen-stefani/ache/" data-viewpointtitle="Lirik Lagu Ache - Gwen Stefani - KapanLagi.com" data-pageloadertargetelm="#ajaxid-9Rh5hQA" data-pageloadermax="3" data-pageloaderpageurl="https://m.kapanlagi.com/lirik/artis/gwen-stefani/ache/" data-pageloaderthisurl="https://m.kapanlagi.com/ajax-m/lirik/artis/gwen-stefani/ache/" data-pageloadernexturl="[&quot;https:\/\/m.kapanlagi.com\/ajax-m\/lirik\/artis\/gwen-stefani\/almost-blue\/&quot;,&quot;https:\/\/m.kapanlagi.com\/ajax-m\/lirik\/artis\/gwen-stefani\/artificial-sweetener\/&quot;,&quot;https:\/\/m.kapanlagi.com\/ajax-m\/lirik\/artis\/gwen-stefani\/asking-for-it-feat-fetty-wap\/&quot;]" data-pageloadershowonly="{&quot;1&quot;:&quot;.showonlypage1&quot;,&quot;2&quot;:&quot;.showonlypage2&quot;,&quot;3&quot;:&quot;.showonlypage3&quot;}">
	<div class="title-detail">
		<h1>Lirik Lagu Ache - <a href="https://m.kapanlagi.com/lirik/artis/gwen-stefani/">Gwen Stefani</a></h1>
	</div>
	
<!--SOCIALTAB-->
<div id="sharebox-zQLM16d" class="sharebox box-share">
	<div class="share clearfix">
		<div id="klsocial-zQLM16d"></div> 
		<script type="text/javascript" src="https://a.kapanlagi.com/v5/js/m/social.js"></script>
		<link rel="stylesheet" href="https://a.kapanlagi.com/v5/css/m/social.css"/>
		<script type="text/javascript"> 
			$(document).ready(function() {
				var shareUrl = "https://m.kapanlagi.com/lirik/artis/gwen-stefani/ache";
				var shareText = "";
				if(!shareText) shareText = undefined;
				$('#klsocial-zQLM16d').klnsosial({
					url: shareUrl,
					text: shareText,
					comment_count:-1,
					twitter_user: 'kapanlagicom'
				});
			});
		</script>
	</div>
</div>
<!--ENDOF SOCIALTAB-->

	
	<div class="deskrip-img">
		<p>ACHE Woke up this morning and felt no too cool<br />
'Cause every time I tried to make my mouth move<br />
The pain I'm having is so discomforting<br />
Please make this suffering go away<br />
<br />
I told my mom what I was feeling<br />
And how long I've been dealing with it<br />
Knew it was coming, but didn't know how soon<br />
She said I've reached another adolescent monsoon<br />
<br />
OOoo Ahh... the pain is tremendous<br />
Why can't I take it like a man<br />
OOoo Ahh... the pain is horrendous<br />
Why don't you lend a helpin' hand<br />
<br />
He was a well-educated man, had his degree in medicine<br />
I noticed his hairy hands... he was a very, very hairy man<br />
He looked right down in, shook his head and then<br />
said "these teeth must be pulled right away!"<br />
<br />
He turned around, rolled up his sleeve<br />
I rolled my eyes then suddenly<br />
A horrible pain grew, the next thing that I knew<br />
The doc had pulled my wisdom teeth...OUT!<br />
Well along with my teeth my money also left me<br />
As he made out the bill, I was moaning<br />
OOoo Ahh... the pain is tremendous<br />
Where the hell is my prescription...of codeine?<br />
<br />
But when will I speak, how long until my mouth feels natural?<br />
How long will they bleed, when will they heal, where's the real meal<br />
? How do you feel? How do you feel? How do you feel? How do you<br />
feel?<br />
<br />
I feel good...I feel great...there's no pain...there's no ache<br />
I feel good...I feel great...just let me recuperate<br />
<br />
Because the codeine has left me drowsy, leave me be...just let me sleep! <br />
</p>
	</div>
	
	

	<!-- FACEBOOK COMMENT -->
	<div class="box-detail clearfix commentbox-box">
		<a href="javascript:void(0)" class="create-comment create-commentbox">BERI KOMENTAR<span><img class="dropdown-icon" src="https://cdns.klimg.com/kapanlagi.com/v5/i/channel/entertainment/arrow-beri-komentar.png" alt="&#9660;" /></span></a>
		<div class="artikel-detail commentbox commentbox-wrapper" style="margin: 0 15px;">
			<h6 class="title-single-kl">Komentar</h6>
			<div id="kplg-comment-box" class="commentbox commentbox-content" data-commentbox-class="fb-comments" data-href="https://m.kapanlagi.com/lirik/artis/gwen-stefani/ache" data-numposts="2" data-colorscheme="light" data-width="100%" data-mobile="true"></div>
		</div>
	</div>
	<!-- ENDOF FACEBOOK COMMENT -->

	
	<div class="searchmusic19">
		<div class="search-box-musik search-box-musik-detail search-bottom-footer">
			
<h6>Cari Lirik Gwen Stefani</h6>
<div class="clearfix">
	<form class="searchmusic19-form" action="https://www.google.com/cse">
		<div class="input-group">
			<input name="q" class="searchmusic19-input" placeholder="Ache - Gwen Stefani" value="" class="text" type="text" />
			<span class="input-group-btn">
				<button class="searchmusic19-submit" type="submit" name="sa">Cari</button>
			</span>
		</div>
		<input type="hidden" value="015807142566320303553:qfwkus9vlfs" name="cx">
		<input type="hidden" value="UTF-8" name="ie">
	</form>
</div>

		</div>
		
		<!--LIRIK NAV-->
		
<ul class="lirik-list-menu searchmusic19-list">
	<li class="showonly showonlypage3"><a href="/hollywood/g/gwen_stefani/berita/"  onclick="dataLayer.push({'event': 'click', 'feature_location': 'under-top-reads', 'feature_name': 'lirik', 'feature_position': 1, 'kanal_page': 'Lihat Berita'});" >Lihat Berita Gwen Stefani</a></li><li class="showonly showonlypage1"><a href="/lirik/artis/gwen-stefani/spark-the-fire/"  onclick="dataLayer.push({'event': 'click', 'feature_location': 'under-top-reads', 'feature_name': 'lirik', 'feature_position': 2, 'kanal_page': 'Lirik Lengkap'});" >Spark The Fire</a></li><li class="showonly showonlypage1"><a href="/lirik/artis/gwen-stefani/shine-with-pharrell-williams/"  onclick="dataLayer.push({'event': 'click', 'feature_location': 'under-top-reads', 'feature_name': 'lirik', 'feature_position': 3, 'kanal_page': 'Lirik Lengkap'});" >Shine with Pharrell Williams</a></li><li class="showonly showonlypage1"><a href="/lirik/artis/gwen-stefani/loveable/"  onclick="dataLayer.push({'event': 'click', 'feature_location': 'under-top-reads', 'feature_name': 'lirik', 'feature_position': 4, 'kanal_page': 'Lirik Lengkap'});" >Loveable</a></li><li class="showonly showonlypage1"><a href="/lirik/artis/gwen-stefani/war-paint/"  onclick="dataLayer.push({'event': 'click', 'feature_location': 'under-top-reads', 'feature_name': 'lirik', 'feature_position': 5, 'kanal_page': 'Lirik Lengkap'});" >War Paint</a></li><li class="showonly showonlypage1"><a href="/lirik/artis/gwen-stefani/splash/"  onclick="dataLayer.push({'event': 'click', 'feature_location': 'under-top-reads', 'feature_name': 'lirik', 'feature_position': 6, 'kanal_page': 'Lirik Lengkap'});" >Splash</a></li><li class="showonly showonlypage2 showonlypage3"><a href="/lirik/artis/gwen-stefani/"  onclick="dataLayer.push({'event': 'click', 'feature_location': 'under-top-reads', 'feature_name': 'lirik', 'feature_position': 7, 'kanal_page': 'Lirik Lengkap'});" >Lirik Lengkap Gwen Stefani</a></li><li class="showonly showonlypage2 showonlypage3"><a href="/lirik/index.html"  onclick="dataLayer.push({'event': 'click', 'feature_location': 'under-top-reads', 'feature_name': 'lirik', 'feature_position': 8, 'kanal_page': '100 lirik lagu teratas'});" >100 lirik lagu teratas</a></li><li class="showonly showonlypage2 showonlypage3"><a href="/lirik/index1.html"  onclick="dataLayer.push({'event': 'click', 'feature_location': 'under-top-reads', 'feature_name': 'lirik', 'feature_position': 9, 'kanal_page': 'Lirik Lagu Top 1-20'});" >Lirik Lagu Top 1-20</a></li><li class="showonly showonlypage3"><a href="/lirik/"  onclick="dataLayer.push({'event': 'click', 'feature_location': 'under-top-reads', 'feature_name': 'lirik', 'feature_position': 10, 'kanal_page': 'Terlaris Hari Ini'});" >Lirik Lagu Terlaris Hari Ini</a></li><li class="showonly showonlypage3"><a href="/lirik/abjad.html"  onclick="dataLayer.push({'event': 'click', 'feature_location': 'under-top-reads', 'feature_name': 'lirik', 'feature_position': 11, 'kanal_page': 'Per Abjad'});" >Lirik Lagu Lengkap Per Abjad</a></li>
</ul>

		<!--ENDOF LIRIK NAV-->
	</div>
	
	<!--DFP SHOWCASE CODE-->
	<div id="div-gpt-ad-kapanlagi-sc" class="banner-sc banner-block showcase showcase1 showonly showonlypage1 showonlypage2"></div>
	<!--END DFP SHOWCASE CODE-->
	
</div>

	</div>
	<!-- ENDOF MAINCONTENT -->
	
	                    <div class="new-KL-box-v2">
                        <h5 class="title-single-line">Top Reads</h5>
                        <ul class="list-trending-v2 artikel-border-list">
                            <li><a href="https://www.kapanlagi.com/foto/berita-foto/indonesia/14-potret-ammar-zoni-kaget-sampai-loncat-dapat-prank-serem-dari-irish-bella-dan-kembarannya.html?utm_source=Hot%20Reads&utm_medium=Contents&utm_campaign=14%20Potret%20Ammar%20Zoni%20Kaget%20Sampai%20Loncat%2C%20Dapat%20Prank%20Serem%20dari%20Irish%20Bella%20dan%20Kembarannya"  onclick="dataLayer.push({'event': 'click', 'feature_location': 'under-lirik', 'feature_name': 'lirik', 'feature_position': 1, 'kanal_page': 'Top Reads'});" >14 Potret Ammar Zoni Kaget Sampai Loncat, Dapat Prank Serem dari Irish Bella dan Kembarannya</a></li><li><a href="https://www.kapanlagi.com/showbiz/selebriti/zaskia-gotik-menikah-dengan-sirajuddin-mahmud-kriss-hatta-kutunggu-jandanya-zaskia-84a4d2.html?utm_source=Hot%20Reads&utm_medium=Contents&utm_campaign=Zaskia%20Gotik%20Menikah%20Dengan%20Sirajuddin%20Mahmud%2C%20Kriss%20Hatta%3A%20Kutunggu%20Jandanya%20Zaskia"  onclick="dataLayer.push({'event': 'click', 'feature_location': 'under-lirik', 'feature_name': 'lirik', 'feature_position': 2, 'kanal_page': 'Top Reads'});" >Zaskia Gotik Menikah Dengan Sirajuddin Mahmud, Kriss Hatta: Kutunggu Jandanya Zaskia</a></li><li><a href="https://www.kapanlagi.com/showbiz/selebriti/ditetapkan-jadi-tersangka-kasus-narkoba-roy-kiyoshi-stres-dan-alami-tekanan-batin-db041b.html?utm_source=Hot%20Reads&utm_medium=Contents&utm_campaign=Ditetapkan%20Jadi%20Tersangka%20Kasus%20Narkoba%2C%20Roy%20Kiyoshi%20Stres%20dan%20Alami%20Tekanan%20Batin"  onclick="dataLayer.push({'event': 'click', 'feature_location': 'under-lirik', 'feature_name': 'lirik', 'feature_position': 3, 'kanal_page': 'Top Reads'});" >Ditetapkan Jadi Tersangka Kasus Narkoba, Roy Kiyoshi Stres dan Alami Tekanan Batin</a></li><li><a href="https://plus.kapanlagi.com/yuk-daftar-kapanlagi-buka-bareng-dan-dapatkan-resep-menu-buka-puasa-andalan-dari-chef-norman-505f40.html" >Yuk Daftar Kapanlagi Buka Bareng dan Dapatkan Resep Menu Buka Puasa Andalan dari Chef Norman!</a></li><li><a href="https://plus.kapanlagi.com/jadwal-sholat-imsak-dan-buka-puasa-ke-18-ramadhan-11-mei-2020-berbagai-daerah-di-indonesia-451007.html" >Jadwal Sholat, Imsak, dan Buka Puasa ke-18 Ramadhan 11 Mei 2020, Berbagai Daerah di Indonesia</a></li>
                        </ul>
                    </div>
	
	<div class="back-to-top-home">
		<a href="#top_kl_logo" class="gotojump">
			<img src="https://cdns.klimg.com/kapanlagi.com/v5/m/i/assets/img/Back-To-Top-Grey.png">
		</a>    
	</div>
</div>
       
		
		<footer>
			<div class="footer text-center">
				<div class="footer-content clearfix">
					<div class="backtop backtop-new gotojump">
						<a href="#top_kl_logo">Back to top <img src="https://cdns.klimg.com/kapanlagi.com/v5/m/i/assets/img/up_circular-32.png" alt="&#8593;" /></a>
					</div>
				</div>                
				<div id="the-awesome-footer-loaded-here" class="elementloader" data-targeturl="https://m.kapanlagi.com/json-element/footer/"></div>
			</div>
		</footer>
		<script type="text/javascript" src="https://a.kapanlagi.com/v5/js/m/elementloader.js"></script>
       
	</div>
	
	
<!--DFP BOTTOM FRAME CODE-->
<div id="dfp-bframe-cont" class="dfp-bframe-cont" style="bottom: 0px; min-height: 50px; width: 100%; position: fixed; z-index: 99999; background-color: #ECECEC70;">
        <center>
                <div id='div-gpt-ad-kapanlagi-bottomfrm' style="text-align: center; width: 320px; margin: 0 auto;"></div>
        </center>
</div>
<!--END DFP BOTTOM FRAME CODE-->

	
	
<!--DFP POPUP CODE-->
	<div id='div-gpt-ad-kapanlagi-popup-oop' style='text-align: center;'></div>
<!--END DFP POPUP CODE-->

	
	<!--DFP NEWSTAG1-->
		<div id='div-gpt-ad-kapanlagi-dfp-newsTag1-oop'></div>
	<!--END DFP NEWSTAG1-->
	
	<!--DFP NEWSTAG2-->
		<div id='div-gpt-ad-kapanlagi-dfp-newsTag2-oop'></div>
	<!--END DFP NEWSTAG2-->

	
	    
	
	
<!--DFP OVERLAY ADS-->
	<div id='div-gpt-ad-dfp-overlay-oop'></div>
<!--END DFP OVERLAY ADS-->
    
	
	<!--DFP RECOMMENDATION ADS CODE-->
	<div id='div-gpt-ad-kapanlagi-recommend-slot-2-oop'></div>
	<div id='div-gpt-ad-kapanlagi-recommend-slot-3-oop'></div>
	<div id='div-gpt-ad-kapanlagi-recommend-slot-9-oop'></div>
	<!--END DFP RECOMMENDATION ADS CODE-->    

	<iframe src="https://d.kapanlaginetwork.com/mga.html?https://m.kapanlagi.com/lirik/artis/gwen-stefani/ache/4Q://a.9T.48/v5/js/m/RD/linkid.js" height="1" width="1"></iframe>
	
	<!--DMP INTEREST--><!--END DMP INTEREST-->
	
	<!--KLN INFEED-->
        <script>
                var infInitCfg = {
                        publisherId : 50715770,
                        wrapperPage : 'https://m.kapanlagi.com/infeed/wrapper.html',
                        seoUrl: true,
                        slots : ['inf-1', 'inf-2', 'inf-3','inf-4', 'inf-5', 'inf-6'],
                        templateID : 150                    
                };
        </script>
        <script src="https://d.infeed.id/resources/js/v0.0.2/infeed-init.js"></script>
<!--ENDOF KLN INFEED-->
	
	<!--DFP CODE-->
	<script>var gpt_gam_ver = 'v04-DK';
    gpt_gam_site = window.location.hostname.toUpperCase();
gpt_gam_ver = (typeof gpt_gam_site !== 'undefined') ? gpt_gam_ver.toUpperCase() : 'V.0.1';
console.log('%c GPT '+gpt_gam_site+' '+gpt_gam_ver ,'color:#d3d3d3; font-size:25px; font-weight: bold; -webkit-text-stroke: 1px black;');
    /*PROTOTYPE CUSTOM FILTERING*/
    String.prototype.klyFiltering = function(delimiter) {
        return this.replace(/[\"\']/g, "").trim().split(delimiter).map(function(t) {
            return t.trim().toLowerCase()
        }).filter(function(x) {
            return x != "";
        });
    };

    window.GAMLibrary = {};
    window.GAMLibrary = {
        dfpSlideup 			: 	'/36504930/m.kapanlagi.com/dfp-slideup',
        dfpExposer1 		: 	'/36504930/m.kapanlagi.com/dfp-exposer-slot1',
        dfpExposer2 		: 	'/36504930/m.kapanlagi.com/dfp-exposer-slot2',
        dfpBottomFrame		: 	'/36504930/m.kapanlagi.com/dfp-bottomfrm',
        dfpTopframe 		: 	'/36504930/m.kapanlagi.com/dfp-topfrm',
        dfpHeadline 		: 	'/36504930/m.kapanlagi.com/dfp-headline',
        scSlot 				: 	'/36504930/m.kapanlagi.com/dfp-sc',
        timedBottomFrm      :  	null,
        setGamBFInterval    :  	function (active = true) {
                                    if (!active) {
                                        clearInterval(window.GAMLibrary.gamBFInterval);
                                        return;
                                    }
                                    window.GAMLibrary.gamBFInterval = setInterval(function () {
                                        document.querySelector("#dfp-spinads") && document.querySelector("#dfp-spinads").parentElement.remove(); 
                                        googletag.pubads().refresh([window.GAMLibrary.refreshSlot]);
                                    }, 60000);
                                },
        documentMeta       :   	function (metaName) {
                                    var metaResult = '';
                                    var metas = document.getElementsByTagName('meta');
                                    if (metas) {
                                        for (var x = 0, y = metas.length; x < y; x++) {
                                            if (metas[x].name.toLowerCase() == metaName) {
                                                metaResult += metas[x].content;
                                            }
                                        }
                                    }
                                    return metaResult != '' ? metaResult : '';
                                },
        inArray             :   function (needle, haystack) {
                                    var length = haystack.length;
                                    for (var i = 0; i < length; i++) {
                                        if (haystack[i] == needle) return true;
                                    }
                                    return false;
                                },                    
        arrToLowerCase      :    function (arr){
                                    return arr.map(function(v,i){
                                        return v.toLowerCase();
                                    });
                                },
        lockScroll          :   {
                                    status: false,
                                    timeout: 3000,
                                    unset: function() {
                                        document.body.style.overflow = "initial";
                                        document.body.style.position = "unset";
                                        document.body.style.width = "unset";
                                        this.status = false;
                                    },
                                    set: function() {
                                        document.body.style.overflow = "hidden";
                                        document.body.style.position = "fixed";
                                        document.body.style.width = window.screen.width + "px";
                                        this.status = true;
                                    }
                                },
        scrollBottomFrame   : 	function() {
                                    this.scroll = function(){
                                                        var scrollNode = document.scrollingElement || document.documentElement;
                                                        var scrollTop = scrollNode.scrollTop;
                                                        if (scrollTop >= "200") {
                                                            // console.log('testing scroll',scrollTop,this.timedBottomFrm);
                                                            window.removeEventListener("scroll", this.scrollHandler);
                                                            
                                                            googletag.display('div-gpt-ad-kapanlagi-bottomfrm');
                                                            googletag.pubads().refresh([this.timedBottomFrm]);

                                                            this.refreshSlot = this.timedBottomFrm;
                                                            this.setGamBFInterval();
                                                        }
                                                    };
                                    this.scrollHandler = this.scroll.bind(this);
                                    window.addEventListener("scroll", this.scrollHandler);
                                },
        initiateSCReadPage	:  function () {
                                    var scContainer = document.querySelectorAll('#div-gpt-ad-kapanlagi-sc'),
                                    idx_scMulti = 1;
                                    scContainer.forEach(function(v,i){
                                        if(!((i+1) % 2)){
                                            scId = 'div-gpt-ad-kapanlagi-sc-'+idx_scMulti;
                                            v.setAttribute('id',scId);
                                            var sc_adunit=  googletag.defineSlot('/36504930/m.kapanlagi.com/dfp-sc', [300, 250], scId).addService(googletag.pubads()).setTargeting("position", [idx_scMulti.toString()]);;
                                                            googletag.display(scId);
                                                            googletag.pubads().refresh([sc_adunit]);
                                            idx_scMulti++;
                                        }
                                    });
                                },
        generateViewabilityTracker : function(){
                                        let isFotoGallery = kly && kly.gtm.type.match(/PhotoGallery/ig);
                                        let vTrackEl = null;
                                        if( isFotoGallery ){
                                            vTrackEl = document.createElement('img');
                                            vTrackEl.setAttribute('src', 'https://pubads.g.doubleclick.net/gampad/clk?id=5255364166&iu=/36504930');
                                            vTrackEl.setAttribute('width', '0');
                                            vTrackEl.setAttribute('height', '0');
                                            vTrackEl.setAttribute('id', 'gam-viewability-tracker-kl-berita-foto');
                                            parent.window.document.body.appendChild(vTrackEl);
                                        }
                                            
                                    }
    
        
    }

    var PWT = {}; //Initialize Namespace
    var googletag = googletag || {};
    googletag.cmd = googletag.cmd || [];
    /* START - LOAD PUBMATIC, GOOGLE ADS & REVIVE */
    PWT.jsLoaded = function() { //PubMatic pwt.js on load callback is used to load GPT
        (function() {
              var gads = document.createElement('script');
              var rads = document.createElement('script'); // #1
              var useSSL = 'https:' == document.location.protocol;
              gads.src = (useSSL ? 'https:' : 'http:') + '//www.googletagservices.com/tag/js/gpt.js';
              rads.src = (useSSL ? 'https:' : 'http:') + '//adserver.kl-youniverse.com/asyncjs.php'; // #2
              gads.async = true;
              rads.async = true; // #3
              var node = document.getElementsByTagName('script')[0];
              node.parentNode.insertBefore(gads, node);
              node.parentNode.insertBefore(rads, node); // #4
        })();
    };
	/* END  - LOAD PUBMATIC, GOOGLE ADS & REVIVE */
    (function() {
        var purl = window.location.href;
        var url = '//ads.pubmatic.com/AdServer/js/pwt/156536/525';
        var profileVersionId = '';
        if (purl.indexOf('pwtv=') > 0) {
            var regexp = /pwtv=(.*?)(&|$)/g;
            var matches = regexp.exec(purl);
            if (matches.length >= 2 && matches[1].length > 0) {
                profileVersionId = '/' + matches[1];
            }
        }
        var wtads = document.createElement('script');
        wtads.async = true;
        wtads.type = 'text/javascript';
        wtads.src = url + profileVersionId + '/pwt.js';
        var node = document.getElementsByTagName('script')[0];
        node.parentNode.insertBefore(wtads, node);
    })();

    /* DMP CATEGORY LIST */
	window.createDMPTracker = function(adsList, dfpTracker) {
		var dmpEl, dmpON, dmpId = 1,
			dmpList = ["fashion-events","acara-film","beauty-events","comedy-events","fan-conventions","lifestyle-events","musical-events","sporting-events","auto-shows","parenting-events","political-event","apartments","life-insurance","motor-insurance","health-insurance","education-insurance","travel-insurance","home-insurance","automotive","auto-racing","beauty","disasters","local-news","law","international-news","crime","national-news","elections","politics","government-business","business-and-finance","cloud-computing","content-channel","education","outdoor-decorating","consumer-electronics","esports","events","family-and-relationships","fashion-anak","mens-fashion","womens-fashion","fitness-and-exercise","fmcg-food-and-drink","fmcg-personal-care","console-games","pc-games","gaming","computer-peripherals","hatchback","health","healthy-and-wellness","home-and-garden","homeschooling","hotels-and-motels","pharmaceutical-industry","financial-industry","entertainment-industry","healthcare-industry","construction-industry","legal-services-industry","power-and-energy-industry","logistics-and-transportation-industry","food-industry","manufacturing-industry","media-industry","mechanical-and-industrial-engineering-industry","automotive-industry","education-industry","aviation-industry","hospitality-industry","advertising-industry","agriculture","real-estate-industry","retail-industry","technology-industry","telecommunications-industry","interior-decorating","internet","residentials-buy-sell-and-rentals","auto-buying-and-selling","credit-cards","household-supplies","injuries","pregnancy","childrens-health","adults-health","mental-health","reproductive-health","computing","bollywood-content","dangdut-content","movie-content","hijab-content","hollywood-content","korean-content","quiz-content","music-content","coffee","course-education","green-vehicles","frozen-foods","fast-foods","side-dishes","desserts-and-baking","snacks","healthy-cooking-and-eating","make-up","marketing-and-advertising","soft-drinks","mobil-cerdas","luxury-cars","budget-cars","performance-cars","mobile-apps","mpv","news-and-politics","nutrition","non-profit-organizations","business-expos-and-conferences","parenting","marketplace/ecommerce","weight-loss","early-childhood-education","alternative-medicine","chronic-disease","ailment","sports-equipment","skin-care","hair-care","body-care","facecare","home-appliances","personal-finance","houses","loans","fmcg-oral-care","fmcg-hair-care","fmcg-body-care","fmcg-face-care","milk-products","tickets-promo-and-vouchers","property","relationship","auto-rentals","sales-and-promotions","primary-education","online-education","private-school","soccer","motorcycles","auto-repair","shopping-and-ecommerce","smartphones","social-networking","computer-software-and-applications","auto-parts","sports","startups","style-and-fashion","suv","water-services","gas-and-electric","internet-service-providers","phone-services","technology-and-computing","television","physical-therapy","train-tickets","flight-tickets","online-transportation","travel","budget-travel","special-interest-tv","childrens-tv","animation-tv","news-tv","drama-tv","comedy-tv","music-tv","sports-tv","reality-tv","college-education","vaccines","wearable-technology","web-hosting","family-travel","culinary-travel","religious-tourism"];
		Array.isArray(adsList) && dmpList.forEach(function(v, k) {
			adsList.forEach(function(l, e) {
				if (v === l) {
					cat = v.trim();
					dmpEl = document.createElement('img');
					dmpON = parent.window.document.querySelector('#dmp-tracker-' + dmpId);
					dmpON ? dmpON.remove() : '';
					dmpEl.setAttribute('src', 'https://beacon.krxd.net/event.gif?event_id=M361oCpv&event_type=registration&cat=' + cat + '&media=banner');
					dmpEl.setAttribute('width', '0');
					dmpEl.setAttribute('height', '0');
					dmpEl.setAttribute('id', 'dmp-tracker-' + dmpId);
					console.log(dmpEl);
					parent.window.document.body.appendChild(dmpEl);
					dmpId++;
				}
			});
		});
		parent.window.open(dfpTracker, '_blank');
	};

    GAMLibrary.generateViewabilityTracker();

    var isReadPage = kly.pageType === "ReadPage";

    if (!document.querySelector("div-gpt-ad-kapanlagi-insertion-oop") && isReadPage) {
        var gamInsertionEl = document.createElement("div");
        gamInsertionEl.id = "div-gpt-ad-kapanlagi-insertion-oop";
        document.body.appendChild(gamInsertionEl);
    }

    googletag.cmd.push(function() {
        var urlPath = document.URL;
        var isMatcont = false;
        var blackListWords = new Array('matcont', 'aduhai', 'kelamin', 'vital', 'anal', 'belahan', 'bercinta', 'bergairah', 'gairah', 'intim', 'bikini', 'bokong', 'boob', 'bra', 'bugil', 'celana', 'ciuman', 'cleavage', 'dada', 'dewasa', 'diremas', 'doggie', 'ejakulasi', 'ereksi', 'erotis', 'foreplay', 'kiss', 'seks', 'gangbang', 'horny', 'hot', 'kamasutra', 'keperawanan', 'perawan', 'kondom', 'kontrasepsi', 'libido', 'lingerie', 'masturbasi', 'mature', 'menggairahkan', 'menggoda', 'mesra', 'miss-v', 'mr-p', 'nakal', 'naughty', 'nipple', 'nipples', 'onani', 'oral', 'oral seks', 'organ', 'orgasme', 'paha', 'pantat', 'panties', 'payudara', 'pelecehan', 'telanjang', 'penetrasi', 'penis', 'perkosa', 'perkosaan', 'pole', 'porno', 'pornoaksi', 'pornografi', 'telentang', 'provokatif', 'putting', 'ranjang', 'sex', 'penetratif', 'seksi', 'seksual', 'sensual', 'seronok', 'doll', 'toys', 'skandal', 'sperma', 'striptease', 'striptis', 'syur', 'terangsang', 'tiduri', 'topless', 'vagina', 'vibrator', 'lendir', 'prostitusi', 'homoseks', 'meraba-raba', 'mesum', 'memerkosa', 'rudapaksa', 'kemaluan', 'kasus asusila', 'pemerkosaan', 'hubungan seksual', 'hubungan intim', 'video porno', 'berita hoax', 'ternyata hoax', 'ahed tamimi', 'konflik palestina israel', 'konflik suriah', 'ujaran kebencian', 'g30s', 'kediktatoran arab saudi', 'konflik palestina-israel', 'fpi', 'penembakan', 'pelecehan seksual', 'tips seks', 'komunitas swinger', 'fenomena kelainan seksual', 'penyimpangan seks', 'posisi seks', 'obat kuat', 'bentuk payudara', 'implan payudara', 'chat firza-rizieq', 'anarkisme suporter sepakbola', 'bentrok suporter', 'pengeroyokan', 'penganiayaan', 'begal motor', 'kekerasan pada wartawan', 'pemerkosaan anak', 'pencabulan', 'bentrokan warga', 'bentrokan', 'kasus narkoba', 'akibat merokok', 'bahaya merokok', 'berhenti merokok', 'cara berhenti merokok', 'efek berhenti merokok', 'larangan merokok', 'tips berhenti merokok', 'rokok elektrik', 'pilpres 2019', 'koalisi pilpres 2019', 'koalisi prabowo', 'koalisi jokowi', 'prabowo-sandiaga', 'ratna sarumpaet', 'capres jokowi', 'capres prabowo', 'kebohongan ratna sarumpaet', 'prabowo subianto', 'jemaah ansharut daulah', 'aliran sesat', 'lia eden', 'kisah mualaf', 'penistaan agama', 'suporter tewas', 'gempa palu', 'gempa donggala', 'gempa sulawesi tengah', 'pembunuhan', 'tsunami palu', 'penemuan mayat', 'lion air jatuh di karawang', 'lion air jatuh', 'pembunuhan sadis', 'lion air hilang kontak', 'pesawat jatuh', 'pesawat hilang kontak', 'kecelakaan', 'kapal tenggelam di danau toba', 'kecelakaan bus', 'kapal tenggelam', 'kasus tabrak lari', 'bunuh diri', 'perselingkuhan', 'kisah perselingkuhan', 'razia pasangan mesum', 'seks bebas', 'gangguan jiwa', 'tes keperawanan', 'kontroversi hukuman mati', 'stres dan depresi', 'ahok gugat cerai veronica tan', 'Kanker', 'Impotensi', 'merokok', 'Perokok', 'Rokok', 'tembakau', 'Pelanggaran', 'Tablet', 'Overdosis', 'Jantung', 'Stroke', 'Cancer', 'Narkoba', 'Djarum', 'Ganja', 'BNN', 'Obesitas', 'Osteoporosis', 'Corona', 'Corona di indonesia', 'virus corona', 'virus-corona', 'covid-19', 'wabah corona', 'menewaskan', 'menewaskan orang', 'mengancam nyawa', 'meninggal', 'meninggal dunia', 'orang mati', 'orang tewas', 'pemakaman', 'petugas penyelamat', 'telah meninggal', 'terbunuh', 'tewas', 'tewaskan', 'tim penyelamat', 'wanita meninggal', 'autopsi', 'belasungkawa', 'bencana', 'bencana besar', 'bunuh orang', 'darurat bencana', 'dilaporkan tewas', 'dimakamkan', 'dipastikan tewas', 'ditemukan mati', 'ditemukan tewas', 'hilangnya nyawa', 'identitas korban', 'inalillahi', 'jasad korban', 'jasadnya', 'jenasah wanita', 'jenazah', 'jenazah pria', 'jenazah teridentifikasi', 'jasad', 'kehilangan hidupnya', 'kehilangan nyawa', 'kehilangan nyawanya', 'kematian', 'korban', 'korban jiwa', 'korban meninggal', 'korban tewas', 'mati', 'mayat', 'mayat korban', 'membunuh', 'membunuh istrinya', 'membunuh mereka', 'membunuh suaminya', 'menemui ajal', 'mengalami koma', 'menghembuskan nafas terakhir', 'menimbulkan korban', 'meninggal akibat sakit', 'menyebabkan kematian', 'meregang nyawa', 'meregggut nyawa', 'modar', 'nyawa hilang', 'nyawa melayang', 'penyebab kematian', 'tak bernyawa', 'tak sadarkan diri', 'terkapar', 'tidak bernyawa', 'tutup usia', 'wafat', 'kematian virus', 'kematian wabah', 'korban terinfeksi', 'virus menyerang', 'merenggut nyawa', 'pelayat', 'hilangkan nyawa', 'renggut nyawa', 'wabah', 'keadaan kritis', 'kehilangan darah', 'merenggut jiwa', 'telan nyawa', 'menelan nyawa', 'memakan nyawa', 'dinyatakan meninggal', 'nyawa tak tertolong', 'penyakit', 'sakit pernapasan', 'sesak', 'korona', 'corona', 'odp', 'pdp', 'virus', 'rumah sakit', 'Covid-19', 'virus korona', 'positif korona', 'COVID-19', 'terjangkit COVID-19', 'terinfeksi virus corona');
        /* POPULATE META DATA KEYWORDS */
        var dfp_pageTitle = kly.article && kly.article.title.klyFiltering(' ');
        var dfp_titles = (typeof dfp_pageTitle !== 'undefined' && dfp_pageTitle.length > 0 ) ? dfp_pageTitle: [];
        var dfp_pageKeywords = GAMLibrary.documentMeta("keywords");
        var dfp_keyword = dfp_pageKeywords.klyFiltering(",");
        /* POPULATE META DATA DESC */
        var dfp_pageDesc = GAMLibrary.documentMeta("description");
        var dfp_desc = dfp_pageDesc.klyFiltering(",");
        var tagForAds = (typeof window.kly !== 'undefined') ? kly.gtm.tag.klyFiltering("|") : [];
        var dfp_keywords = dfp_keyword.concat(dfp_titles, dfp_desc, tagForAds);
        var isMultipage = window.kly.article["isMultipage"].toString();
        /*MATURE CONTENT DEFINED VAR*/
        if (!blackListWords) {
            var blackListWords = new Array('matcont');
        }
        /*CONTENT FILTERING SCRIPT*/
        blackListWords = GAMLibrary.arrToLowerCase(blackListWords);
        dfp_keywords.forEach(function(sKeyword) {
            sKeyword = sKeyword.toLowerCase();
            tagForAds.push(sKeyword);
            if (GAMLibrary.inArray(sKeyword.trim(), blackListWords)) {
                isMatcont = true;
            }
        });

        /*DEFINE ALL SLOT*/
        googletag.defineSlot(GAMLibrary.dfpHeadline, [
            [320, 50],
            [320, 100]
        ], 'div-gpt-ad-kapanlagi-hl').addService(googletag.pubads());
        googletag.defineSlot(GAMLibrary.scSlot, [300, 250], 'div-gpt-ad-kapanlagi-sc').addService(googletag.pubads());
        googletag.defineSlot(GAMLibrary.dfpExposer1, [
            [300, 250],
            [300, 600],
            [320, 480]
        ], 'div-gpt-ad-kapanlagi-dfp-exposer-slot1-oop').addService(googletag.pubads());

        /*OUT OF PAGE SLOTS*/
        googletag.defineOutOfPageSlot(GAMLibrary.dfpTopframe, 'div-gpt-ad-kapanlagi-topfrm-oop').addService(googletag.pubads());
        googletag.defineOutOfPageSlot('/36504930/m.kapanlagi.com/dfp-recommend-slot-2', 'div-gpt-ad-kapanlagi-recommend-slot-2-oop').addService(googletag.pubads());
        googletag.defineOutOfPageSlot('/36504930/m.kapanlagi.com/dfp-recommend-slot-3', 'div-gpt-ad-kapanlagi-recommend-slot-3-oop').addService(googletag.pubads());
        googletag.defineOutOfPageSlot('/36504930/m.kapanlagi.com/dfp-recommend-slot-9', 'div-gpt-ad-kapanlagi-recommend-slot-9-oop').addService(googletag.pubads());
        googletag.defineOutOfPageSlot('/36504930/m.kapanlagi.com/dfp-newsTag1', 'div-gpt-ad-kapanlagi-dfp-newsTag1-oop').addService(googletag.pubads());
        googletag.defineOutOfPageSlot('/36504930/m.kapanlagi.com/dfp-newsTag2', 'div-gpt-ad-kapanlagi-dfp-newsTag2-oop').addService(googletag.pubads());
        googletag.defineOutOfPageSlot('/36504930/m.kapanlagi.com/dfp-visual-story-1', 'div-gpt-ad-kapanlagi-visual-story-1-oop').addService(googletag.pubads());
        googletag.defineOutOfPageSlot('/36504930/m.kapanlagi.com/dfp-visual-story-2', 'div-gpt-ad-kapanlagi-visual-story-2-oop').addService(googletag.pubads());
        googletag.defineOutOfPageSlot('/36504930/m.kapanlagi.com/dfp-visual-story-3', 'div-gpt-ad-kapanlagi-visual-story-3-oop').addService(googletag.pubads());
        googletag.defineOutOfPageSlot(GAMLibrary.dfpExposer2, 'div-gpt-ad-kapanlagi-dfp-exposer-slot2-oop').addService(googletag.pubads());
        googletag.defineOutOfPageSlot(GAMLibrary.dfpSlideup, 'div-gpt-ad-dfp-overlay-oop').addService(googletag.pubads());
        if (isReadPage) {
            googletag.defineOutOfPageSlot('/36504930/m.kapanlagi.com/dfp-insertion', 'div-gpt-ad-kapanlagi-insertion-oop').addService(googletag.pubads());
            googletag.defineOutOfPageSlot('/36504930/m.kapanlagi.com/dfp-contextual', 'div-gpt-ad-kapanlagi-mobile-contextual-oop').addService(googletag.pubads());
        }

        /*Bottom Frame Scrolling*/
        GAMLibrary.timedBottomFrm = googletag.defineSlot(GAMLibrary.dfpBottomFrame, [[320, 50],[320, 100]], 'div-gpt-ad-kapanlagi-bottomfrm').addService(googletag.pubads());
        GAMLibrary.scrollBottomFrame();
        /*Bottom Frame Scrolling*/

        googletag.pubads().addEventListener('slotResponseReceived', function(event) {
            var dfp_slotDelivered = event.slot.getResponseInformation() ? 'block' : 'none'; /* check wheter there is ads or not*/
            var dfp_slotAdUnitPath = event.slot.getSlotId().getAdUnitPath(); /* get adunit path */

            /*check if native ads creative was delivered*/
            if (dfp_slotDelivered == 'block') {
                if (dfp_slotAdUnitPath == GAMLibrary.dfpHeadline) {
                    var urlParams = new URLSearchParams(window.location.search);
                    var myParam = JSON.parse(urlParams.get('interval'));
                    headlineSticky(myParam);
                }
                
                /*check for topframe rendering process */
                if (dfp_slotAdUnitPath == GAMLibrary.dfpTopframe) {
                    let deviceOrientation = (window.innerHeight < window.innerWidth ? 1 : 0);
                    var that = GAMLibrary.lockScroll;
                    GAMLibrary.lockScroll.set();

                    if (GAMLibrary.lockScroll.status) {
                        setTimeout(function() {
                            that.unset();
                        }, that.timeout);
                    } else {
                        GAMLibrary.lockScroll.unset();
                    }
                    if (deviceOrientation) {
                        GAMLibrary.lockScroll.unset();
                    }
                    window.addEventListener("resize", function() {
                        let deviceOrientation = (window.innerHeight < window.innerWidth ? 1 : 0);
                        if (deviceOrientation) {
                            that.unset();
                        }
                    });
                }
            } else {
                var dfp_slotElementId = event.slot.getSlotId().getDomId();
                if (dfp_slotElementId.match(/newsTag|recommend/)) {
                    if (document.getElementById(dfp_slotElementId) && document.getElementById(dfp_slotElementId).getElementsByTagName('iframe')[0] && document.getElementById(dfp_slotElementId).getElementsByTagName('iframe')[0].getAttribute('height') == 1) {
                        document.getElementById(dfp_slotElementId).getElementsByTagName('iframe')[0].style.display = "none";
                    }

                }
            }
        });

        /*INITIATE ADS ON CONTINOUS PAGE */
        GAMLibrary.initiateSCReadPage();

        /** BEGIN CRITEO CDB **/
        ! function() {
            var e = {
                    "300x250": 962381,
                    "728x90": 962382,
                    "320x50": 962383,
                    "970x90": 962384,
                    "300x600": 980819,
                },
                t = "L",
                z = 8;
            "F" != (t = t.toUpperCase()) && "L" != t && "A" != t && (t = "L");
            var i = {
                    placements: []
                },
                o = {},
                a = {};
            for (var g in googletag.pubads().getSlots())
                if (googletag.pubads().getSlots().hasOwnProperty(g)) {
                    var r = googletag.pubads().getSlots()[g];
                    o[p = r.getSlotElementId()] = [], a[p] = 0;
                    for (var n in r.getSizes())
                        if (r.getSizes().hasOwnProperty(n)) {
                            var s = r.getSizes()[n],
                                d = e[s.getWidth() + "x" + s.getHeight()] || null;
                            if (d) {
                                var l = s.getWidth() * s.getHeight();
                                a[p] = l > a[p] ? l : a[p], o[p].push({
                                    slotid: p,
                                    zoneid: d,
                                    width: s.getWidth(),
                                    height: s.getHeight(),
                                    area: l
                                })
                            }
                        }
                }
            var h = 0;
            for (var p in o) {
                var u = o[p];
                for (var g in u) {
                    var v = u[g];
                    if (h >= z) break;
                    if (("L" != t || v.area == a[v.slotid]) && (i.placements.push({
                            slotid: p,
                            zoneid: v.zoneid
                        }), h++, "F" == t)) break
                }
            }
            if (i.placements.length > 0) {
                window.Criteo = window.Criteo || {}, window.Criteo.events = window.Criteo.events || [], googletag.pubads().disableInitialLoad();
                var f = function() {
                    googletag.cmd.push(function() {
                        Criteo.SetDFPKeyValueTargeting(), googletag.pubads().refresh()
                    })
                };
                Criteo.events.push(function() {
                    Criteo.SetLineItemRanges("0..30:0.01"), Criteo.RequestBids(i, f, 2000)
                })
            }
        }();
        /** END CRITEO CDB **/

        /*  START TARGETING BLOCK   */
        if (isMatcont) { googletag.pubads().setTargeting("isMatcont", ["1"]);}
        if(typeof Krux !== "undefined"){
            googletag.pubads().setTargeting('ksg', Krux.segments);
            googletag.pubads().setTargeting('kuid', Krux.user);
        }
        googletag.pubads().setTargeting("tags",tagForAds);
        googletag.pubads().setTargeting("currentUrl", urlPath);
        googletag.pubads().setTargeting("type", kly.gtm.type);
        googletag.pubads().setTargeting("pageType", kly.pageType);
        googletag.pubads().setTargeting("channel", kly.channel.full_slug);
        googletag.pubads().setTargeting("audience", typeof (audience = kly.gtm.audience && kly.gtm.audience.split("|")) === "undefined" ? "false" : audience);
        googletag.pubads().setTargeting("isAdvertorial", typeof (isAdvertorial = kly.article && kly.article.isAdvertorial.toString()) === "undefined" ? "false" :  isAdvertorial);   
        googletag.pubads().setTargeting("isMultipage", typeof (isMultipage = kly.article && kly.article.isMultipage.toString()) === "undefined" ? "false" : isMultipage );
        googletag.pubads().setTargeting("articleId", kly.gtm.articleId.toString());
        googletag.pubads().setTargeting("pagingNum", typeof (pageParam = kly.gtm.pageParam && kly.gtm.pageParam.toString()) === "undefined" ? "false" : pageParam );
        googletag.pubads().setTargeting("newExp",typeof (newExp = kly.gtm.new_exp) === "undefined" ? "false" : kly.gtm.new_exp.toString());
        /*  END TARGETING BLOCK   */

        googletag.pubads().setCentering(true);
        googletag.pubads().enableSingleRequest();
        googletag.enableServices();

    });

        googletag.cmd.push(function() {
        googletag.display('div-gpt-ad-kapanlagi-topfrm-oop');
        });
        googletag.cmd.push(function() {
        googletag.display('div-gpt-ad-kapanlagi-hl');
        });
        googletag.cmd.push(function() {
        googletag.display('div-gpt-ad-kapanlagi-sc');
        });
        googletag.cmd.push(function() {
        googletag.display('div-gpt-ad-kapanlagi-dfp-newsTag1-oop');
        });
        googletag.cmd.push(function() {
        googletag.display('div-gpt-ad-kapanlagi-dfp-newsTag2-oop');
        });
        googletag.cmd.push(function() {
        googletag.display('div-gpt-ad-kapanlagi-recommend-slot-2-oop');
        });
        googletag.cmd.push(function() {
        googletag.display('div-gpt-ad-kapanlagi-recommend-slot-3-oop');
        });
        googletag.cmd.push(function() {
        googletag.display('div-gpt-ad-kapanlagi-recommend-slot-9-oop');
        });
        googletag.cmd.push(function() {
        googletag.display('div-gpt-ad-kapanlagi-visual-story-1-oop');
        });
        googletag.cmd.push(function() {
        googletag.display('div-gpt-ad-kapanlagi-visual-story-2-oop');
        });
        googletag.cmd.push(function() {
        googletag.display('div-gpt-ad-kapanlagi-visual-story-3-oop');
        });
        if (isReadPage) {
        googletag.cmd.push(function() {
            googletag.display('div-gpt-ad-kapanlagi-insertion-oop');
        });
        googletag.cmd.push(function() {
            googletag.display('div-gpt-ad-kapanlagi-mobile-contextual-oop');
        });
        }
        var gptMKapanlagiStyle = document.createElement('style');
        gptMKapanlagiStyle.textContent = '.div-gpt-ad-kapanlagi-sc-continous{margin-bottom:30px}';
        document.body.appendChild(gptMKapanlagiStyle);

        /* ===== HEADLINESTICKY METHOD - DEFAULT 3s ===== */
        var headlineStickyInterval=3,headlineStickyStatus=!1;function headlineSticky(t){null!=t&&(headlineStickyInterval=t),console.log(headlineStickyInterval);var e=document.getElementById("div-gpt-ad-kapanlagi-hl"),n=document.createElement("div");n.setAttribute("id","div-gpt-ad-kapanlagi-hl-shadow"),e.parentElement.insertBefore(n,e),injectStickyStyleAndAnimation(),window.addEventListener("scroll",headlineStickyScrollEevent)}function headlineStickyScrollEevent(){var t=document.getElementById("div-gpt-ad-kapanlagi-hl"),e=document.getElementById("div-gpt-ad-kapanlagi-hl-shadow").getBoundingClientRect().top;document.querySelector(".layout__nav-content"),document.documentElement.scrollTop||document.body.scrollTop;headlineStickyStatus?e<=0||(window.removeEventListener("scroll",headlineStickyScrollEevent),removeStickyHeadline(t,!1)):e<=0&&(t.classList.add("hl-active-sticky"),t.style="",removeStickyHeadline(t,!0),headlineStickyStatus=!0)}function removeStickyHeadline(t,e){var n=setInterval(function(){headlineStickyInterval<=0?(t.classList.remove("hl-active-sticky"),t.classList.remove("hl-navbar-hanging"),t.style.margin="10px 0",clearInterval(n),window.removeEventListener("scroll",headlineStickyScrollEevent)):headlineStickyInterval--},1e3);e||(clearInterval(n),t.classList.remove("hl-active-sticky"),t.classList.remove("hl-navbar-hanging"),t.style.margin="10px 0")}function injectStickyStyleAndAnimation(){var t=document.createElement("style");t.textContent="\n\t\t.hl-active-sticky {\n\t\t\tposition: fixed;\n\t\t\ttop: -100%;\n\t\t\tz-index: 9999;\n\t\t\tleft: 50%;\n\t\t\ttransform: translateX(-50%);\n\t\t\tmargin: 0;\n\t\t\ttransition : margin-top .5s ease;\n\t\t\tanimation: hlSlideDown .5s forwards;\n\t\t}\n\n\t\t.hl-navbar-hanging{\n\t\t\tmargin-top : 50px !important;\n\t\t}\n\n\t\t@keyframes hlSlideDown{\n\t\t\t0%{top : -100px;}\n\t\t\t100%{top : 0px;}\n\t\t}\n\t\t",document.head.appendChild(t)}
        /* ===== HEADLINESTICKY METHOD ===== */</script>
		<!--END DFP CODE-->
	
	
	
</body>
</html>
